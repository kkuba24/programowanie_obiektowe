﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class Aukcja
    {
        List<IObserwator> ListaKlientów = new List<IObserwator>();
        public int Id;
        public string Opis;
        public double Cena;
        public DateTime DataZakończenia;
        public Aukcja(int id, string opis, double cena, DateTime datazakończenia)
        {
            this.Id = id;
            this.Opis = opis;
            this.Cena = cena;
            this.DataZakończenia = datazakończenia;
        }
        public void DodajKlienta(Klient x)
        {
            ListaKlientów.Add(x);
        }
        public void ZmianaCeny(double cena)
        {
            this.Cena = cena;
            Powiadomienie(new PowiadomienieCena(Cena));
        }
        public void ZmianaDaty(DateTime datazakończenia)
        {
            this.DataZakończenia = datazakończenia;
            Powiadomienie(new PowiadomienieDataZakonczenia(DataZakończenia));
        }
        public void ZmianaOpisu(string opis)
        {
            this.Opis = opis;
            Powiadomienie(new PowiadomienieOpis(Opis));
        }

        void Powiadomienie(Powiadomienie x)
        {
            foreach (var item in ListaKlientów)
            {
                item.Update(x);
            }
        }

    }
}
