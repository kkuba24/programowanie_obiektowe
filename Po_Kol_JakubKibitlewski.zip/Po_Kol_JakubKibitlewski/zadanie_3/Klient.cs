﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class Klient : IObserwator
    {
        string nazwa;
        public Klient(string klient)
        {
            this.nazwa = klient;
        }

        public void Update(Powiadomienie klient)
        {
            Console.WriteLine(klient.GetWiadomosc());
        }
    }
}
