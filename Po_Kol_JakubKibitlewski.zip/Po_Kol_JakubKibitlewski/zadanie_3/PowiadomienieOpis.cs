﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class PowiadomienieOpis : Powiadomienie
    {
        string aukcja;
        public PowiadomienieOpis(string a)
        {
            this.aukcja = a;
        }

        public override string GetWiadomosc()
        {
            return aukcja;

        }
    }
}
