﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Aukcja BMW = new Aukcja(1, "Niemiec pod kocem trzymał", 20000, DateTime.Today);

            BMW.DodajKlienta(new Klient("Krzychu"));
            BMW.DodajKlienta(new Klient("Grzegorz"));
            BMW.DodajKlienta(new Klient("Zdzichu"));
            BMW.ZmianaCeny(22000);
            
            Console.ReadKey();
        }
    }
}
