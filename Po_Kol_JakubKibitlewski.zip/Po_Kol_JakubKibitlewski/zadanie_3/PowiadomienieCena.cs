﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class PowiadomienieCena : Powiadomienie
    {
        double aukcja;
        public PowiadomienieCena(double a)
        {
            this.aukcja = a;
        }
        public override string GetWiadomosc()
        {
            return "Zmiana ceny na " + aukcja;

        }
    }
}
