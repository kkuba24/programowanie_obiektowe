﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_3
{
    class PowiadomienieDataZakonczenia : Powiadomienie
    {
        DateTime aukcja;
        public PowiadomienieDataZakonczenia(DateTime a)
        {
            this.aukcja = a;
        }
        public override string GetWiadomosc()
        {
            return "Zmiana daty zakonczenia " + aukcja;

        }
    }
}
