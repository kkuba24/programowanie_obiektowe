﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_2
{
    class Pracownik
    {
        public string Imie;
        public string Nazwisko;
        public long Pesel;
        public double Pensja;
        public int Wiek;

        public Pracownik(string imie, string nazwisko, long pesel, double pensja, int wiek)
        {
            this.Imie = imie;
            this.Nazwisko = nazwisko;
            this.Pesel = pesel;
            this.Pensja = pensja;
            this.Wiek = wiek;
        }

    }
}
