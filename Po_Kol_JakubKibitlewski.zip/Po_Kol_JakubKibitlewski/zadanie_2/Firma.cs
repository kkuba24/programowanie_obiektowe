﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_2
{
    class Firma
    {
        public List<Pracownik> pracownicy = new List<Pracownik>();
        public Dictionary<long, double> PobierzPracownikowZPensjaMniejszaNiz(double p)
        {
            Dictionary<long, double> słownik = new Dictionary<long, double>();
            foreach (var pracownik in pracownicy)
            {
                if (pracownik.Pensja < p)
                    słownik.Add(pracownik.Pesel, pracownik.Pensja);
            }

            return słownik;
        }
        public void WypiszSłownik(Dictionary<long, double> słownik)
        {
            foreach (var pracownik in słownik)
            {
                Console.WriteLine("\t" + pracownik.Key + " - " + pracownik.Value.ToString());
            }
        }
    }
}
