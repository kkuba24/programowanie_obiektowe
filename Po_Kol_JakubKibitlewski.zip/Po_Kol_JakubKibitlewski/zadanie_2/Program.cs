﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Pracownik Wiesiek = new Pracownik("Wiesław", "Paleta", 47030212323, 2500, 73);
            Pracownik Czesiek = new Pracownik("Czesław", "Walaszek", 69121232123, 2350, 51);
            Pracownik Darek = new Pracownik("Dariusz", "Krzak", 68840218980, 2600, 52);
            Pracownik Arek = new Pracownik("Arkadiusz", "Milik", 80231023213, 2900, 40);
            Pracownik Krzychu = new Pracownik("Krzysztof", "Jęczydół", 91310721312, 3400, 29);


            Firma firma = new Firma();

            firma.pracownicy.Add(Wiesiek);
            firma.pracownicy.Add(Czesiek);
            firma.pracownicy.Add(Darek);
            firma.pracownicy.Add(Arek);
            firma.pracownicy.Add(Krzychu);

            
            Dictionary<long, double> pracownicy = firma.PobierzPracownikowZPensjaMniejszaNiz(2900);
            firma.WypiszSłownik(pracownicy);

            Console.ReadKey();
        }
    }

    

    
}
