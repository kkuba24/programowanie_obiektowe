﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    class Prom
    {
        private double ladownosc = 12000;
        private double masaPojazdow;
        private List<Pojazd> pojazdy = new List<Pojazd>();
        private bool załadowany;

        public double MasaZaladowanychPojazdow()
        {
            masaPojazdow = 0;
            return masaPojazdow;
        }
        public void WyladujPojazd(Pojazd p)
        {
            pojazdy.Remove(p);
            masaPojazdow -= p.Masa;
        }
        public void ZaladujPojazd(Pojazd p)
        {

            try
            {
                pojazdy.Add(p);
                masaPojazdow += p.Masa;
                if (masaPojazdow > ladownosc)
                    throw (new WyczerpanaŁadowność("Dopuszczalna ładowność przekroczona"));
            }
            catch (WyczerpanaŁadowność e)
            {

                throw;
            }



        }
    }
}
