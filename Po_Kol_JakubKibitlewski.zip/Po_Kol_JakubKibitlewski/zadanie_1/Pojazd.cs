﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    abstract class Pojazd
    {
        public double Masa;
        public string Nazwa;
        //public Pojazd(double masa, string nazwa)
        //{
        //    this.Masa = masa;
        //    this.Nazwa = nazwa;
        //}
    }
}
