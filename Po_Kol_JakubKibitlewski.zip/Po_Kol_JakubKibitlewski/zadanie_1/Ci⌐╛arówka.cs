﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    class Ciężarówka : Pojazd
    {
        public Ciężarówka(double masa, string nazwa)
        {
            this.Masa = masa;
            this.Nazwa = nazwa;
        }
    }
}
