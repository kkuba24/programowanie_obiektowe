﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Pojazd O1 = new Osobowy(1750, "BMW");
            Pojazd O2 = new Osobowy(1200, "KIA");

            Pojazd C1 = new Ciężarówka(5500, "Mercedes");
            Pojazd C2 = new Ciężarówka(6000, "Daf");

            Prom P1 = new Prom();
            P1.ZaladujPojazd(O1);
            P1.ZaladujPojazd(O2);
            P1.ZaladujPojazd(C1);
            P1.ZaladujPojazd(C2);

            Console.ReadKey();

        }
    }
}
