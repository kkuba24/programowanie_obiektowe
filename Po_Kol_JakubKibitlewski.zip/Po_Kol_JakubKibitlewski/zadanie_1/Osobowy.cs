﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    class Osobowy : Pojazd
    {
        public Osobowy(double masa, string nazwa)
        {
            this.Masa = masa;
            this.Nazwa = nazwa;
        }
        
    }
}
