﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_1
{
    class WyczerpanaŁadowność : Exception
    {
        public WyczerpanaŁadowność(string message) : base(message)
        {

        }
    }
}
